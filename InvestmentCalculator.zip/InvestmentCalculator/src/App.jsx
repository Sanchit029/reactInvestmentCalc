import Header from "./Components/Header"
import UserInput from "./Components/UserInput"
import Result from "./Components/Result"
import { useState } from "react";

function App() {

  const [value, setValue] = useState({
    initialInvestment: 0,
    annualInvestment: 0,
    expectedReturn: 0,
    duration: 0,
  });

  return (
    <>
    <Header/>
    <UserInput getValue = {setValue}/>
    <Result data = {value}/>
    </>
  )
}

export default App
