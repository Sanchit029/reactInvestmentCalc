import { useState } from "react";
export default function InputField({name,value}) {
  const[inputValue,setInputValue] = useState(0);
  const[inputType,setInputType] = useState('text');
  let variable = "";
  switch (name)
  {
    case ("Initial Investment"):
    variable = "initialInvestment";
    break;
    
    case ("Annual Investment"):
    variable = "annualInvestment";
    break;

    case ("Expected Return"):
    variable = "expectedReturn";
    break;

    case ("Duration"):
    variable = "duration";
    break;

  };
  function handleInputType(type)
  {
    setInputType(type);

    if(type === "text")
    {
      value((prev)=>(
      {
        ...prev,
        [variable]:Number(inputValue),
      }));
    }
  }
  function handleInputValue(event)
  {
    const numericValue = Number(event.target.value);
    setInputValue(Number(numericValue));
  }
  return (
      <p>
          <label>{name}</label>
          <input type={inputType}
          onClick={() => handleInputType('number')}
          onBlur={()=>handleInputType('text')}
          onChange={handleInputValue}
          value={inputValue} />
        </p>
   
  );
}
