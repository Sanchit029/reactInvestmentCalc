import TableRow from "./TableRow.jsx";
import TableHead from "./TableHead.jsx";
import {calculateInvestmentResults} from "../util/investment.js"
export default function Result({data}) {
  const array = calculateInvestmentResults(data);
  return (
    <table id="result">
      <thead>
        <TableHead />
      </thead>
      <tbody>
        <TableRow array={array} />
      </tbody>
    </table>
  );
}
