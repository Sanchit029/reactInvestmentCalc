export default function TableHead() {
  return (
    <tr>
      <th>Year</th>
      <th>Investment Value</th>
      <th>Interest(Year)</th>
      <th>Total Interest</th>
      <th>Invested Capital</th>
    </tr>
  );
}
