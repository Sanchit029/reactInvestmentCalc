import { formatter } from "../util/investment";

export default function TableRow({ array }) {
  return (
    <>
      {array.map((element) => {
        const totalInterest = formatter.format(
          element.valueEndOfYear.toFixed(0) - element.investedCapital
        );
        const investmentValue = formatter.format(
          element.valueEndOfYear.toFixed(0)
        );
        const year = element.year;
        const interestYear = formatter.format(element.interest.toFixed(0));
        const investedCapital = formatter.format(element.investedCapital);
        return (
          <tr key={element.year}>
            <td>{year}</td>
            <td>{investmentValue}</td>
            <td>{interestYear}</td>
            <td>{totalInterest}</td>
            <td>{investedCapital}</td>
          </tr>
        );
      })}
    </>
  );
}
