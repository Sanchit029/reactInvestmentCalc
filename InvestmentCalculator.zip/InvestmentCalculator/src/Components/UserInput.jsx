
import InputField from "./InputField";

export default function UserInput({getValue}) {
  
  return (
    <section id="user-input">
      <div className="input-group">
        <InputField
          name="Initial Investment"
          value={getValue}
        />
        <InputField 
        name="Annual Investment" 
        value = {getValue}
        />
      </div>
      <div className="input-group"> 
        <InputField
         name="Expected Return" 
         value={getValue}
         />
        <InputField 
        name="Duration"
        value={getValue}
         />
      </div>
    </section>
  );
}
